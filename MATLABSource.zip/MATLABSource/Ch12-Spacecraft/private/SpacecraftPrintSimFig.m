f = {'Attitude' 'Body_Rates' 'RWA_Rates' 'Control_Torque' 'Angular_Momentum' 'Angular_Errors'};
t = 'att';
for k = 1:6
  s = sprintf('Figure12-%d_%s_%s',k+9,f{k},t);
  PrintFig(1,2,k,s);
end