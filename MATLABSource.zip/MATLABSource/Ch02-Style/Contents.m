% CH02-STYLE
%
% Files
%   Dot                  - Dot product of two arrays.
%   MemoExample          - Technical Memo Example
%   OverloadedFunction   - An example of an internally overloaded function with actions.
%   ScriptDemo           - This is a template for a script layout.
%   FunctionWithBuiltins - Function with built-in inputs and outputs
%
% Supporting
%   Demo.mat             - Saved workspace from ScriptDemo

