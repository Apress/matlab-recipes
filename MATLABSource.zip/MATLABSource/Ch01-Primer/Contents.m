% CH01-PRIMER
%
% Files
%   NewBookFile        - Create a new function with the default header style. 
%   parentFunction     - Example of a parent function with a nested function.
%   ParseAndSaveHeader - Save the header of a function to a new file.
%   foo                - Example of extended help in subfunctions.
%   varargFunction     - Example of a function using varargin and varargout.
